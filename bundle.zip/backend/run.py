# Built at Fri Feb 17 08:36:22 UTC 2023
import sys

print("Running Backend...")
print("Python version is: " + sys.version)

sys.exit(0)

