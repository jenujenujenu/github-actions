# Built at Fri Feb 17 07:13:43 UTC 2023
import sys

print("Running Backend...")
print("Python version is: " + sys.version)

sys.exit(0)

